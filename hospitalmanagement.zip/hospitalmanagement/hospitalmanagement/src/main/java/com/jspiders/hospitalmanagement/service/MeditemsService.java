package com.jspiders.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.MeditemsDao;
import com.jspiders.hospitalmanagement.dto.Meditems;

@Service
public class MeditemsService {

	@Autowired
	private MeditemsDao meditemsDao;

	public Meditems saveMeditems(Meditems meditems, int mid) {
		return meditemsDao.saveMeditems(meditems, mid);
	}

	public Meditems updateMeditems(Meditems meditems, int id) {
		Meditems meditems2 = meditemsDao.getMeditemsById(id);
		meditems.setMedorder(meditems2.getMedorder());
		Meditems dbMeditems = meditemsDao.updateMeditems(id, meditems);
		if (dbMeditems != null) {
			return meditems;
		} else {
			return null;
		}
	}

	public Meditems deleteMeditems(int id) {
		Meditems meditems = meditemsDao.deleteMeditems(id);
		if (meditems != null) {
			return meditems;
		} else {
			return null;
		}
	}

	public Meditems getMeditemsById(int id) {
		Meditems meditems = meditemsDao.getMeditemsById(id);
		if (meditems != null) {
			return meditems;
		} else {
			return null;
		}
	}
}