package com.jspiders.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.HospitalDao;
import com.jspiders.hospitalmanagement.dto.Hospital;

@Service
public class HospitalService {

	@Autowired
	private HospitalDao hospitalDao;

	public Hospital saveHospital(Hospital hospital) {
		return hospitalDao.saveHospital(hospital);
	}

	public Hospital updateHospital(int hid, Hospital hospital) {
		Hospital hospital2 = hospitalDao.updateHospital(hid, hospital);
		if (hospital2 != null) {
			return hospital2;
		} else {
			return null;
		}
	}

	public Hospital deleHospital(int hid) {
		Hospital hospital = hospitalDao.deleteHospital(hid);
		if (hospital != null) {
			return hospital;
		} else {
			return null;
		}
	}

	public Hospital getHospitalById(int hid) {
		Hospital hospital = getHospitalById(hid);
		if (hospital != null) {
			return hospital;
		}else {
			return null;
		}
	}
	
	public Hospital getHospitalbyEmail(String email) {
		Hospital hospital = hospitalDao.getHospitalByEmail(email);
		if (hospital != null) {
			return hospital;
		}else {
			return null;
		}
	}
}
