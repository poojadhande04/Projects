package com.jspiders.hospitalmanagement.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.BranchDao;
import com.jspiders.hospitalmanagement.dao.EncounterDao;
import com.jspiders.hospitalmanagement.dao.PersonDao;
import com.jspiders.hospitalmanagement.dto.Branch;
import com.jspiders.hospitalmanagement.dto.Encounter;
import com.jspiders.hospitalmanagement.dto.Person;

@Service
public class EncounterService {

	@Autowired
	private EncounterDao encounterDao;

	@Autowired
	private PersonDao personDao;

	@Autowired
	private BranchDao branchDao;

	public Encounter saveEncounter(Encounter encounter, int pid, int bid) {
		Person person = personDao.getPersonById(pid);
		Branch branch = branchDao.getBranchById(bid);
		encounter.setPerson(person);
		List<Branch> list = new ArrayList<>();
		list.add(branch);
		encounter.setList(list);
		return encounterDao.saveEncounter(encounter);
	}

	public Encounter updateEncounter(int eid, Encounter encounter,int bid) {
		Encounter encounter2 = encounterDao.getEncounterById(eid);
		Branch branch = branchDao.getBranchById(bid);
		
		List<Branch> list =  encounter2.getList();
		encounter.setList(encounter2.getList());
		encounter.setPerson(encounter2.getPerson());
	    return encounterDao.updateEncounter(eid, encounter);
	}

	public Encounter deleteEncounter(int eid) {
		Encounter encounter = encounterDao.deleteEncounterById(eid);
		if (encounter != null) {
			return encounter;
		} else {
			return null;
		}
	}

	public Encounter getEncounterById(int eid) {
		Encounter encounter = encounterDao.getEncounterById(eid);
		if (encounter != null) {
			return encounter;
		} else {
			return null;
		}
	}
}
