package com.jspiders.hospitalmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.PersonDao;
import com.jspiders.hospitalmanagement.dto.Person;

@Service
public class PersonService {

	@Autowired
	private PersonDao personDao;

	public Person savePerson(Person person) {
		return personDao.savePerson(person);
	}

	public Person updatePerson(int pid, Person person) {
		Person person2 = personDao.updatePerson(pid, person);
		if (person2 != null) {
			return person2;
		} else {
			return null;
		}
	}

	public Person deletePerson(int pid) {
		Person person = personDao.deletePerson(pid);
		if (person != null) {
			return person;
		}else {
			return null;
		}
	}
	
	public Person getPersonById(int pid) {
		Person person = personDao.getPersonById(pid);
		if (person != null) {
			return person;
		}else {
			return null;
		}
	}
	
}
