package com.jspiders.hospitalmanagement.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.AddressDAO;
import com.jspiders.hospitalmanagement.dto.Address;
import com.jspiders.hospitalmanagement.exception.Idnotfound;

@Service
public class AddressService {

	@Autowired
	private AddressDAO addressDao;

	public Address saveAddress(Address address) {
		return addressDao.saveAddress(address);
	}

	public Address updateAddress(Address address, int aid) {  
		Address address2 = addressDao.updateAddress(aid, address);
		if (address2 != null) {
			return address2;
		} else {
			throw new Idnotfound("id not found for the address");
		}
	}

	public Address deleteAddress(int aid) {
		Address address = addressDao.deleteAddress(aid);
		if (address != null) {
			return address;
		} else {
			throw new Idnotfound("id not found for the address");
		}
	}

	public Address getAddressById(int aid) {
		Address address = addressDao.getAddressById(aid);
		if (address != null) {
			return address;
		} else {
			throw new NoSuchElementException("no id found");
		}
	}
}
