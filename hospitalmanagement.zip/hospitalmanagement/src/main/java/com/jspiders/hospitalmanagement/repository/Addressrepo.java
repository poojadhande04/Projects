package com.jspiders.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.hospitalmanagement.dto.Address;

public interface Addressrepo extends JpaRepository<Address,Integer>{

}
