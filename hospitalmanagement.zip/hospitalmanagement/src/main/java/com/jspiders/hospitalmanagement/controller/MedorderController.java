package com.jspiders.hospitalmanagement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.hospitalmanagement.dto.Medorder;
import com.jspiders.hospitalmanagement.service.MedorderService;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/medorder")
public class MedorderController {
	
	@Autowired
	private MedorderService medorderservice;
	
	@ApiOperation(value="save medorder",notes="api is used to save medorder")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully saved")})
	@PostMapping
	public ResponseEntity<ResponseStructure<Medorder>> saveMedorder(@Valid @RequestBody Medorder medorder,@RequestParam int eid) {
		return medorderservice.saveMedorder(medorder,eid);
	}
	
	@ApiOperation(value="update medorder",notes="api is used to update medorder")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully updated"),@ApiResponse(code=404,message="id not found")})
	@PutMapping
	public ResponseEntity<ResponseStructure<Medorder>> updateorder(@Valid @RequestBody Medorder medorder,@RequestParam int mid) {
		return medorderservice.updateMedorder(mid, medorder);
	}
	
	@ApiOperation(value="deleted medorder",notes="api is used to deleted medorder")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully deleted medorder"),@ApiResponse(code=404,message="id not found")})
	@DeleteMapping
	public ResponseEntity<ResponseStructure<Medorder>> deleteorder(@RequestParam int mid) {
		return medorderservice.deleteMedorder(mid);
	}
	
	@ApiOperation(value="get medorder",notes="api is used to find medorder based on id")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully found"),@ApiResponse(code=404,message="id not found")})
	@GetMapping
	public ResponseEntity<ResponseStructure<Medorder>> getMedorderById(@RequestParam int mid) {
		return medorderservice.getMedorderById(mid);
	}

}
