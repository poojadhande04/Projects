package com.jspiders.hospitalmanagement.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.BranchDAO;
import com.jspiders.hospitalmanagement.dto.Branch;

import com.jspiders.hospitalmanagement.exception.Idnotfound;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

@Service
public class BranchService {

	@Autowired
	private BranchDAO branchDao;

	public ResponseEntity<ResponseStructure<Branch>> saveBranch(Branch branch, int hid, int aid) {
		ResponseStructure<Branch> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("Successfully saved...");
		responsestructure.setStatus(HttpStatus.CREATED.value());
		responsestructure.setData(branchDao.saveBranch(branch, hid, aid));
		return new ResponseEntity<ResponseStructure<Branch>>(responsestructure,HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Branch>>updateBranch(int bid, Branch branch) {
		Branch branch2 = branchDao.updateBranch(bid, branch);
		if (branch2 != null) {
			ResponseStructure<Branch> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully updated...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(branch2);
			return new ResponseEntity<ResponseStructure<Branch>>(responsestructure,HttpStatus.OK) ;
		} else {
			throw new Idnotfound("id not found for the branch");
		}
	}
	
	public ResponseEntity<ResponseStructure<Branch>> deleteBranch(int bid) {
		Branch branch = branchDao.deleteBranch(bid);
		if (branch != null) {
			ResponseStructure<Branch> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully deleted...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(branch);
			return new ResponseEntity<ResponseStructure<Branch>>(responsestructure,HttpStatus.OK);	
		}else {
			throw new Idnotfound("id not found for the branch");
		}
	}
	
	public ResponseEntity<ResponseStructure<Branch>> getBranchById(int bid) {
		Branch branch = branchDao.getBranchById(bid);
		if (branch != null) {
			ResponseStructure<Branch> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully found...");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(branch);
			return  new ResponseEntity<ResponseStructure<Branch>>(responsestructure,HttpStatus.FOUND);	
		}else {
			throw new NoSuchElementException("no id found");
		}
	}
}