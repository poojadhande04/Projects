package com.jspiders.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.hospitalmanagement.dto.Meditems;

public interface Meditemsrepo extends JpaRepository<Meditems,Integer>{

}
