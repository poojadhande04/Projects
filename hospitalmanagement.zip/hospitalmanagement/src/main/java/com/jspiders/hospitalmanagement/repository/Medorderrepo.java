package com.jspiders.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.hospitalmanagement.dto.Medorder;

public interface Medorderrepo extends JpaRepository<Medorder,Integer> {

}
