package com.jspiders.hospitalmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.BranchDAO;
import com.jspiders.hospitalmanagement.dao.EncounterDAO;
import com.jspiders.hospitalmanagement.dao.PersonDAO;
import com.jspiders.hospitalmanagement.dto.Branch;
import com.jspiders.hospitalmanagement.dto.Encounter;
import com.jspiders.hospitalmanagement.dto.Person;
import com.jspiders.hospitalmanagement.exception.Idnotfound;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

@Service
public class EncounterService {

	@Autowired
	private EncounterDAO encounterDao;

	@Autowired
	private PersonDAO personDao;
 
	@Autowired
	private BranchDAO branchDao;

	public ResponseEntity<ResponseStructure<Encounter>> saveEncounter(Encounter encounter, int pid, int bid) {
		Person person = personDao.getPersonById(pid);
		Branch branch = branchDao.getBranchById(bid);
		encounter.setPerson(person);
		List<Branch> list = new ArrayList<>();
		list.add(branch);
		encounter.setList(list);
		ResponseStructure<Encounter> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("Successfully saved");
		responsestructure.setStatus(HttpStatus.CREATED.value());
		responsestructure.setData(encounterDao.saveEncounter(encounter));
		return new ResponseEntity<ResponseStructure<Encounter>>(responsestructure,HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Encounter>> updateEncounter(int eid, Encounter encounter,int bid) {
		Encounter encounter2 = encounterDao.getEncounterById(eid);
		Branch branch = branchDao.getBranchById(bid);
		
		List<Branch> list =  encounter2.getList();
		encounter.setList(encounter2.getList());
		encounter.setPerson(encounter2.getPerson());
		ResponseStructure<Encounter> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("Successfully updated");
		responsestructure.setStatus(HttpStatus.OK.value());
		responsestructure.setData(encounterDao.updateEncounter(eid, encounter));
		return new ResponseEntity<ResponseStructure<Encounter>>(responsestructure,HttpStatus.OK);
	   
	}

	public ResponseEntity<ResponseStructure<Encounter>> deleteEncounter(int eid) {
		Encounter encounter = encounterDao.deleteEncounterById(eid);
		if (encounter != null) {
			ResponseStructure<Encounter> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully deleted");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(encounter);
			return new ResponseEntity<ResponseStructure<Encounter>>(responsestructure,HttpStatus.OK);
		} else {
			throw new Idnotfound("id not found for the Encounter");
		}
	}

	public ResponseEntity<ResponseStructure<Encounter>> getEncounterById(int eid) {
		Encounter encounter = encounterDao.getEncounterById(eid);
		if (encounter != null) {
			ResponseStructure<Encounter> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully found");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(encounter);
			return new ResponseEntity<ResponseStructure<Encounter>>(responsestructure,HttpStatus.FOUND);
 		} else {
			throw new NoSuchElementException("no id found");
		}
	}
}
