package com.jspiders.hospitalmanagement.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jspiders.hospitalmanagement.dto.Address;
import com.jspiders.hospitalmanagement.repository.Addressrepo;

@Repository
public class AddressDAO {
	@Autowired
	private Addressrepo addressrepo;
	
	public Address saveAddress(Address address) {
		return addressrepo.save(address);
	}
	
	public Address updateAddress(int aid,Address address) {
		if(addressrepo.findById(aid).isPresent()) {
			address.setAid(aid);
			return addressrepo.save(address);
		}
		else {
			return null;
		}
	}
	
	public Address deleteAddress(int aid) {
		if(addressrepo.findById(aid).isPresent()) {
			Address address=addressrepo.findById(aid).get();
			return address;
		}
		else {
			return null;
		}
	}
	public Address getAddressById(int aid) {
		if(addressrepo.findById(aid).isPresent()) {
			return addressrepo.findById(aid).get();
		}
		else {
			return null;
		}
	}

	

}
