package com.jspiders.hospitalmanagement.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.MeditemsDAO;

import com.jspiders.hospitalmanagement.dto.Meditems;
import com.jspiders.hospitalmanagement.exception.Idnotfound;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

@Service
public class MeditemsService {

	@Autowired
	private MeditemsDAO meditemsDao;

	public ResponseEntity<ResponseStructure<Meditems>> saveMeditems(Meditems meditems, int mid) {
		ResponseStructure<Meditems> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("Successfully saved...");
		responsestructure.setStatus(HttpStatus.CREATED.value());
		responsestructure.setData(meditemsDao.saveMeditems(meditems, mid));
		return new ResponseEntity<ResponseStructure<Meditems>>(responsestructure,HttpStatus.CREATED);
	}

	public  ResponseEntity<ResponseStructure<Meditems>>updateMeditems(Meditems meditems, int id) {
		Meditems meditems2 = meditemsDao.getMeditemsById(id);
		meditems.setMeorder(meditems2.getMeorder());
		Meditems dbMeditems = meditemsDao.updateMeditems(id, meditems);
		if (dbMeditems != null) {
			ResponseStructure<Meditems> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully updated...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(meditems2);
			return new ResponseEntity<ResponseStructure<Meditems>>(responsestructure,HttpStatus.OK) ;
		} else {
			throw new Idnotfound("id not found for the Meditems");
		}
	}

	public ResponseEntity<ResponseStructure<Meditems>> deleteMeditems(int id) {
		Meditems meditems = meditemsDao.deleteMeditems(id);
		if (meditems != null) {
			ResponseStructure<Meditems> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully deleted...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(meditems);
			return new ResponseEntity<ResponseStructure<Meditems>>(responsestructure,HttpStatus.OK);
		} else {
			throw new Idnotfound("id not found for the Meditems");
		}
	}

	public ResponseEntity<ResponseStructure<Meditems>> getMeditemsById(int id) {
		Meditems meditems = meditemsDao.getMeditemsById(id);
		if (meditems != null) {
			ResponseStructure<Meditems> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully found...");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(meditems);
			return new ResponseEntity<ResponseStructure<Meditems>>(responsestructure,HttpStatus.FOUND);
		} else {
			throw new NoSuchElementException("no id found");
		}
	}
}