package com.jspiders.hospitalmanagement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.hospitalmanagement.dto.Person;
import com.jspiders.hospitalmanagement.service.PersonService;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/person")
public class PersonController {
	@Autowired
	private PersonService personservice;
	
	@ApiOperation(value="save person",notes="api is used to save person")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully saved")})
	@PostMapping
	public ResponseEntity<ResponseStructure<Person>> savePerson(@Valid @RequestBody Person person) {
		return personservice.savePerson(person);
	}
	
	@ApiOperation(value="update person details",notes="api is used to update person details")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully updated"),@ApiResponse(code=404,message="id not found")})
	@PutMapping
	public ResponseEntity<ResponseStructure<Person>> updatePerson(@RequestParam int pid,@RequestBody Person person) {
		return personservice.updatePerson(pid, person);
	}
	
	@ApiOperation(value="deleted person details",notes="api is used to delete the person details")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully deleted"),@ApiResponse(code=404,message="id not found")})
	@DeleteMapping
	public ResponseEntity<ResponseStructure<Person>> deletePerson(@RequestParam int pid) {
		return personservice.deletePerson(pid);
	}
    
	@ApiOperation(value="get person",notes="api is used to find a person based on id")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully found"),@ApiResponse(code=404,message="id not found")})
	@GetMapping
	public ResponseEntity<ResponseStructure<Person>> getPersonById(@RequestParam int pid) {
		return personservice.getPersonById(pid);
	}
}
