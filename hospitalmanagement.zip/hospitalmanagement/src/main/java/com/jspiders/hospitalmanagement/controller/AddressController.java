package com.jspiders.hospitalmanagement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.hospitalmanagement.dto.Address;
import com.jspiders.hospitalmanagement.service.AddressService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/address")
public class AddressController {
	 @Autowired
     private AddressService addressservice;
	 
	 @ApiOperation(value="save address",notes="api is used to save address")
	 @ApiResponses(value= {@ApiResponse(code=201,message="successfully saved address")})
	 @PostMapping
	 public Address saveAddress(@Valid @RequestBody Address address) {
		 return addressservice.saveAddress(address);
	 }
	 
	 @ApiOperation(value="update address",notes="api is used to update the address of hospital")
		@ApiResponses(value= {@ApiResponse(code=201,message="successfully updated"),@ApiResponse(code=404,message="id not found")})
	 @PutMapping
	 public Address updateAddress(@RequestParam int aid,@RequestBody Address address) {
		 return addressservice.updateAddress(address,aid);
	 }
	 
	 @ApiOperation(value="delete address",notes="api is used to delete the hospital address")
	 @ApiResponses(value= {@ApiResponse(code=201,message="successfully deleted"),@ApiResponse(code=404,message="id not found")})
	 @DeleteMapping
	 public Address deleteAddress(@RequestParam int aid) {
		 return addressservice.deleteAddress(aid);
	 }
	 
	 @ApiOperation(value="get address",notes="api is used to find the address by aid")
		@ApiResponses(value= {@ApiResponse(code=201,message="successfully found"),@ApiResponse(code=404,message="id not found")})
	 @GetMapping
	 public Address getAddressById(@RequestParam int aid) {
		 return addressservice.getAddressById(aid);
	 }
}
