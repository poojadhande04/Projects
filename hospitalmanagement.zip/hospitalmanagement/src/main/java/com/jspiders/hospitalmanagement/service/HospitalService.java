package com.jspiders.hospitalmanagement.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.HospitalDAO;
import com.jspiders.hospitalmanagement.dto.Hospital;
import com.jspiders.hospitalmanagement.exception.Idnotfound;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

@Service
public class HospitalService {

	@Autowired
	private HospitalDAO hospitalDao;
	
	public ResponseEntity<ResponseStructure<Hospital>> saveHospital(Hospital hospital) {
		ResponseStructure< Hospital> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("sucessfully saved");
		responsestructure.setStatus(HttpStatus.CREATED.value());
		responsestructure.setData(hospitalDao.saveHospital(hospital));
		return new ResponseEntity<ResponseStructure<Hospital>>(responsestructure,HttpStatus.CREATED);
		
	}
	public ResponseEntity<ResponseStructure<Hospital>> updateHospital(int hid,Hospital hospital) {
		Hospital hospital2=hospitalDao.updateHospital(hid, hospital);
		ResponseStructure<Hospital> responsestructure=new ResponseStructure<>();
		if(hospital2!=null) {
			responsestructure.setMessage("sucessfully updated");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(hospital2);
			return new ResponseEntity<ResponseStructure<Hospital>>(responsestructure,HttpStatus.OK);
		}else {
			throw new Idnotfound("id not found for the hospital");
		}
		
	}
	public ResponseEntity<ResponseStructure<Hospital>> deleteHospital(int hid) {
		Hospital hospital=hospitalDao.deleteHospital(hid);
		if(hospital!=null) {
			ResponseStructure<Hospital> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("sucessfully deleted");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(hospital);
			return new ResponseEntity<ResponseStructure<Hospital>>(responsestructure,HttpStatus.OK);
		}else {
			throw new Idnotfound("id not found for the hospital");
		}
		
	}
	public ResponseEntity<ResponseStructure<Hospital>> getHospitalbyid(int hid) {
		Hospital hospital=hospitalDao.getHospitalById(hid);
		if(hospital!=null) {
			ResponseStructure<Hospital> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("sucessfully found");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(hospital);
			return new ResponseEntity<ResponseStructure<Hospital>>(responsestructure,HttpStatus.FOUND);
		}else {
			throw new NoSuchElementException("no id found");
		}
		
	}
	public ResponseEntity<ResponseStructure<Hospital>> gethospitalbyemail(String email) {
		Hospital hospital=hospitalDao.gethospitalbyemail(email);
		if(hospital!=null) {
			ResponseStructure<Hospital> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("sucessfully found");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(hospital);
			return new ResponseEntity<ResponseStructure<Hospital>>(responsestructure,HttpStatus.FOUND);

		}else {
			throw new NoSuchElementException("no id found");
		}
		
	}
}





