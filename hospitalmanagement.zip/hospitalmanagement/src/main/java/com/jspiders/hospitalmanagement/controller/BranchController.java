package com.jspiders.hospitalmanagement.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jspiders.hospitalmanagement.dto.Branch;
import com.jspiders.hospitalmanagement.service.BranchService;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/branch")
public class BranchController {
	
	@Autowired
	private BranchService branchservice;
	
	@ApiOperation(value="save branch",notes="api is used to save the branch")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully saved branch of a hospital")})
	@PostMapping
	public ResponseEntity<ResponseStructure<Branch>> saveBranch(@Valid @RequestBody Branch branch,@RequestParam int hid,@RequestParam int aid) {
		return branchservice.saveBranch(branch, hid, aid);
	}
	@ApiOperation(value="update branch",notes="api is used to update the branch")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully updated"),@ApiResponse(code=404,message="id not found")})
	@PutMapping
	public ResponseEntity<ResponseStructure<Branch>> updateBranch(@Valid @RequestBody Branch branch,@RequestParam int aid) {
		return branchservice.updateBranch(aid, branch);
	}
	
	@ApiOperation(value=" delete branch",notes="api is used to delete the branch")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully deleted"),@ApiResponse(code=404,message="id not found")})
	@DeleteMapping
	public ResponseEntity<ResponseStructure<Branch>> deleteBranch(@RequestParam int bid) {
		return branchservice.deleteBranch(bid);
	}
	
	@ApiOperation(value="get branch",notes="api is used to find the branch based on its id")
	@ApiResponses(value= {@ApiResponse(code=201,message="successfully found"),@ApiResponse(code=404,message="id not found")})
	@GetMapping
	public ResponseEntity<ResponseStructure<Branch>> getBranchById(@RequestParam int hid) {
		return branchservice.getBranchById(hid);
	}
	

}
