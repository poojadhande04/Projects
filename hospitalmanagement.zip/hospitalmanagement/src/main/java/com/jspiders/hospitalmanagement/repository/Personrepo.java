package com.jspiders.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspiders.hospitalmanagement.dto.Person;

public interface Personrepo extends JpaRepository<Person,Integer> {

}
