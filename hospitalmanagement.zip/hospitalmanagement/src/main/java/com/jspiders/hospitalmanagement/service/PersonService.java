package com.jspiders.hospitalmanagement.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.PersonDAO;

import com.jspiders.hospitalmanagement.dto.Person;
import com.jspiders.hospitalmanagement.exception.Idnotfound;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

@Service
public class PersonService {

	@Autowired
	private PersonDAO personDao;

	public ResponseEntity<ResponseStructure<Person>> savePerson(Person person) {
		ResponseStructure<Person> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("Successfully saved...");
		responsestructure.setStatus(HttpStatus.CREATED.value());
		responsestructure.setData(personDao.savePerson(person));
		return new ResponseEntity<ResponseStructure<Person>>(responsestructure,HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Person>> updatePerson(int pid, Person person) {
		Person person2 = personDao.updatePerson(pid, person);
		if (person2 != null) {
			ResponseStructure<Person> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully updated...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(person2);
			return new ResponseEntity<ResponseStructure<Person>>(responsestructure,HttpStatus.OK);
		} else {
			throw new Idnotfound("id not found for the person");
		}
	}

	public ResponseEntity<ResponseStructure<Person>> deletePerson(int pid) {
		Person person = personDao.deletePerson(pid);
		if (person != null) {
			ResponseStructure<Person> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully deleted..");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(person);
			return  new ResponseEntity<ResponseStructure<Person>>(responsestructure,HttpStatus.OK);
		}else {
			throw new Idnotfound("id not found for the person");
		}
	}
	
	public ResponseEntity<ResponseStructure<Person>> getPersonById(int pid) {
		Person person = personDao.getPersonById(pid);
		if (person != null) {
			ResponseStructure<Person> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully found...");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(person);
			return  new ResponseEntity<ResponseStructure<Person>>(responsestructure,HttpStatus.FOUND);
		}else {
			throw new NoSuchElementException("no id found");
		}
	}
	
}
