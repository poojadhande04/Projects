package com.jspiders.hospitalmanagement.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jspiders.hospitalmanagement.dao.MedorderDAO;

import com.jspiders.hospitalmanagement.dto.Medorder;
import com.jspiders.hospitalmanagement.exception.Idnotfound;
import com.jspiders.hospitalmanagement.util.ResponseStructure;

@Service
public class MedorderService {

	@Autowired
	private MedorderDAO medorderDao;

	public ResponseEntity<ResponseStructure<Medorder>> saveMedorder(Medorder medorder, int eid) {
		ResponseStructure<Medorder> responsestructure=new ResponseStructure<>();
		responsestructure.setMessage("Successfully saved...");
		responsestructure.setStatus(HttpStatus.CREATED.value());
		responsestructure.setData(medorderDao.saveMedorder(medorder, eid));
		return new ResponseEntity<ResponseStructure<Medorder>>(responsestructure,HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Medorder>> updateMedorder(int mid, Medorder medorder) {

		Medorder medorder2 = medorderDao.getMedorderById(mid);
		medorder.setEncounter(medorder2.getEncounter());
		Medorder dbMedorder = medorderDao.updateMedorder(mid, medorder);
		if (dbMedorder != null) {
			ResponseStructure<Medorder> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully updated...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(dbMedorder);
			return new ResponseEntity<ResponseStructure<Medorder>>(responsestructure,HttpStatus.OK);
		} else {
			throw new Idnotfound("id not found for the Medorder");
		}
	}

	public ResponseEntity<ResponseStructure<Medorder>> deleteMedorder(int mid) {
		Medorder medorder = medorderDao.deleteMedorderById(mid);
		if (medorder != null) {
			ResponseStructure<Medorder> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully deleted...");
			responsestructure.setStatus(HttpStatus.OK.value());
			responsestructure.setData(medorder);
			return new ResponseEntity<ResponseStructure<Medorder>>(responsestructure,HttpStatus.OK) ;
		} else {
			throw new Idnotfound("id not found for the Medorder");
		}
	}

	public ResponseEntity<ResponseStructure<Medorder>>getMedorderById(int mid) {
		Medorder medorder = medorderDao.getMedorderById(mid);
		if (medorder != null) {
			ResponseStructure<Medorder> responsestructure=new ResponseStructure<>();
			responsestructure.setMessage("Successfully found...");
			responsestructure.setStatus(HttpStatus.FOUND.value());
			responsestructure.setData(medorder);
			return  new ResponseEntity<ResponseStructure<Medorder>>(responsestructure,HttpStatus.FOUND) ;
		} else {
			throw new NoSuchElementException("no id found");
		}
	}
}
