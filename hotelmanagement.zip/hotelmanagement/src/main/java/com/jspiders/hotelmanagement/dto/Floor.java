package com.jspiders.hotelmanagement.dto;

//constant values that doesn't change that values  are called as enum.
public enum Floor {
	
    GROUND,FIRST,SECOND;
}
